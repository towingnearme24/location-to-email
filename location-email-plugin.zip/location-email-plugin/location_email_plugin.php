<?php
/**
 * Plugin Name: Location Email Plugin
 * Description: A simple plugin that sends an email with the customer location.
 * Version: 1.0
 * Author: Towingnearme247.com
 */

// Step 1: Create a settings page
function location_email_settings_page() {
    ?>
    <div class="wrap">
        <h2>Location Email Plugin Settings</h2>
        <form method="post" action="options.php">
            <?php
                settings_fields('location_email_settings');
                do_settings_sections('location_email_settings');
            ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Recipient Email</th>
                    <td>
                        <input type="email" name="location_email_recipient" value="<?php echo esc_attr(get_option('location_email_recipient')); ?>" />
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Google Maps API Key</th>
                    <td>
                        <input type="text" name="location_email_api_key" value="<?php echo esc_attr(get_option('location_email_api_key')); ?>" />
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Shortcode</th>
                    <td>
                        <code>[location_email_shortcode]</code>
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}


function location_email_admin_menu() {
    add_options_page('Location Email Plugin Settings', 'Location Email Settings', 'manage_options', 'location-email-settings', 'location_email_settings_page');
}

add_action('admin_menu', 'location_email_admin_menu');

// Step 2: Retrieve and use settings
function location_email_function() {
    // Retrieve settings
    $to_email = get_option('location_email_recipient');
    $api_key = get_option('location_email_api_key');

    ob_start(); // start output buffering
    ?>
    <div id="map" style="height: 400px; width: 100%;"></div>
    
    <script>
    let map, marker;

    function initMap(lat, lng) {
        const location = { lat: lat, lng: lng };
        
        if (!map) {
            map = new google.maps.Map(document.getElementById("map"), {
                zoom: 15,
                center: location,
            });
        }

        if (marker) marker.setMap(null); // Remove the previous marker if exists
        
        marker = new google.maps.Marker({
            position: location,
            map: map,
        });

        map.setCenter(location); // Set map center to the new location
    }

    function getLocation() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(sendLocation, handleError);
        } else {
            alert("Geolocation is not supported by this browser.");
        }
    }

    function handleError(error) {
        console.error("Geolocation Error: ", error);
    }

    function sendLocation(position) {
        const lat = position.coords.latitude;
        const lng = position.coords.longitude;
        const mapLink = `https://www.google.com/maps?q=${lat},${lng}`;

        initMap(lat, lng);

        const data = {
            action: 'location_sender_send_email',
            to_email: '<?php echo esc_js($to_email); ?>',
            message_html: `Customer Location: <a href="${mapLink}" target="_blank">${mapLink}</a>`
        };

        jQuery.post('<?php echo admin_url('admin-ajax.php'); ?>', data)
            .done(function(response) {
                if(response.success) {
                    alert('Location sent successfully! We have received your location.');
                } else {
                    console.error('Failed to send location!', response);
                    alert('Failed to send location!');
                }
            })
            .fail(function(jqXHR, textStatus, errorThrown) {
                console.error("AJAX Error: ", textStatus, errorThrown);
                alert('An error occurred while sending location.');
            });
    }

    jQuery(document).ready(function($) {
        // Ensure Google Maps API is loaded
        if (typeof google === 'object' && typeof google.maps === 'object') {
            getLocation();
        } else {
            console.error('Google Maps API is not loaded!');
            alert('Unable to load the map. Please refresh the page.');
        }
    });
    </script>

    <?php
    return ob_get_clean(); // return the buffered output
}

add_shortcode('location_email_shortcode', 'location_email_function');

// Step 3: Save and Validate Settings
function location_email_register_settings() {
    register_setting('location_email_settings', 'location_email_recipient', 'sanitize_email');
    register_setting('location_email_settings', 'location_email_api_key');
}

add_action('admin_init', 'location_email_register_settings');

// Step 4: Send Email Function (Unchanged)
function location_sender_send_email() {
    $to_email = sanitize_email($_POST['to_email']);
    $message_html = wp_kses_post($_POST['message_html']);
    $headers = array('Content-Type: text/html; charset=UTF-8');
    
    if(wp_mail($to_email, 'Customer Location', $message_html, $headers)) {
        wp_send_json_success();
    } else {
        wp_send_json_error();
    }
}

add_action('wp_ajax_location_sender_send_email', 'location_sender_send_email');
add_action('wp_ajax_nopriv_location_sender_send_email', 'location_sender_send_email');
