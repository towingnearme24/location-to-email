# Location Email Plugin

![Version](https://img.shields.io/badge/version-1.0-brightgreen.svg)

## Description

The Location Email Plugin is a simple yet powerful tool for collecting and sending customer location information via email. This plugin leverages Google Maps Geolocation API to automatically obtain the customer's current location (with their permission), and then sends this location data to a designated email address of your choice. Whether you're running a delivery service, a customer support platform, or just want to know where your visitors are coming from, this plugin can be a valuable addition to your WordPress site.

## Features

- Automatically collects the customer's current location.
- Sends location information to a designated email address.
- Uses the Google Maps Geolocation API for accurate location data.
- Easy-to-use shortcode for embedding location capture in your posts and pages.

## Installation

1. Download the plugin zip file from the [GitHub repository](https://github.com/your-repo-url).

2. Log in to your WordPress admin panel.

3. Navigate to the "Plugins" section and click on "Add New."

4. Click the "Upload Plugin" button, and then upload the plugin zip file you downloaded in step 1.

5. Activate the plugin.

## Usage

### Prerequisites

Before using the Location Email Plugin, you will need:

- A Google Maps Geolocation API Key. You can obtain this key by following Google's [API Key setup instructions](https://developers.google.com/maps/gmp-get-started#create-project).

### Configuring Settings

1. Once the plugin is activated, go to the WordPress admin dashboard.

2. Click on "Settings" and then "Location Email Settings."

3. Here, you will see two options:

   - **Recipient Email**: Enter the email address where you want to receive location notifications.

   - **Google Maps API Key**: Enter your Google Maps Geolocation API Key obtained in the prerequisites step.

4. Save your settings.

### Embedding the Location Capture

You can embed the location capture functionality into any post or page by using the following shortcode:

